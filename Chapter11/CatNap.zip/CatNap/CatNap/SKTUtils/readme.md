https://github.com/raywenderlich/SKTUtils
