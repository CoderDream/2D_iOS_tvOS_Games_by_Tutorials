//
//  SpringNode.swift
//  CatNap
//
//  Created by coderdream on 2019/1/4.
//  Copyright © 2019 CoderDream. All rights reserved.
//

import SpriteKit

class SpringNode: SKSpriteNode, CustomNodeEvents, InteractiveNode {
    func didMoveToScene() {
        isUserInteractionEnabled = true
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        interact()
    }
    
    func interact() {
        isUserInteractionEnabled = false
        
        physicsBody!.applyImpulse(CGVector(dx: 0, dy: 250), at: CGPoint(x: size.width / 2, y: size.height))
        
        run(SKAction.sequence([
                SKAction.wait(forDuration: 1),
                SKAction.removeFromParent()
            ]))
    }
}
